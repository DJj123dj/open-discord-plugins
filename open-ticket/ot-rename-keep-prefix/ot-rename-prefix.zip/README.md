# OT Rename Keep Prefix
A simple plugin to keep the channel prefix when using the /rename command.