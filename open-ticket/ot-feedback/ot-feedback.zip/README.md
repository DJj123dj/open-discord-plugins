# OT Feedback
A plugin to gather feedback of your support service in the DM of the ticket creator and send it to a webhook!