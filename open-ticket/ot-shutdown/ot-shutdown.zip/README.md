# OT Shutdown
A simple plugin to turn off the bot from a discord command (server & bot owner only).

> ### Temporary Shutdown
> If you're searching for a way to temporarily shut-down the ticket system, check the OT Kill Switch plugin!