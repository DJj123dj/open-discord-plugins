# OT Kill Switch
Adds a simple command to jump to the top of the ticket.