# OT Assign Role
This plugin assigns a predefined role to a user upon creating a ticket. Great for permissions and user organization.