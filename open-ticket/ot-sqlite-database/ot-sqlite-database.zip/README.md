# OT SQLite Database
Tired of having the database as JSON files? With this plugin, the database will be an SQLite file!

> ### Large Servers
> This plugin is a must-have for large servers because it will increase the performance a lot!
>
> It's recommended to install this plugin if you have more than `500 members` or `15 active tickets`.

### Migration
Enable the `migrateFromJson` variable in the config if you want to migrate all data over to the SQLite Database.

> This action will EMPTY the json databases!