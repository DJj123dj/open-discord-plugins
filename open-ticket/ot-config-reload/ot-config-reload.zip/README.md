# OT Config Reload
This plugin adds a new command that allows reloading the Open Ticket config files without the need for a restart.

> Note that this command only reloads the **Open Ticket configuration** and does not affect the configuration of other plugins.