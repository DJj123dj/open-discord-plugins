# OT Move Actions
Automatically unclaim/unpin a ticket when it's moved using /move.