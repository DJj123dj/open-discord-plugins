# OT Kill Switch
Temporarily disable the ticket system using a kill switch. When active, no-one is able to create a ticket.