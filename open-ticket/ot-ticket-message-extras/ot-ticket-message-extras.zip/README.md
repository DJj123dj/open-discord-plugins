# OT Ticket Message Extra's
A plugin which adds a few little features to the ticket message that make it more customisable!